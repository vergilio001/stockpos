package stock.stockpos.Utils;

import java.io.File;

public class StringConstants {
    public static final String CSV_DIR = "stockpos" +
            File.separator + "tmp" +
            File.separator + "products" +
            File.separator + "stock.csv";

}
